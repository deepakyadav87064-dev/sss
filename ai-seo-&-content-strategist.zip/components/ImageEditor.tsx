import React, { useState, useCallback, useRef } from 'react';
import { GeminiService } from '../services/geminiService';
import Spinner from './Spinner';

interface ImageEditorProps {
  geminiService: GeminiService;
}

const ImageEditor: React.FC<ImageEditorProps> = ({ geminiService }) => {
  const [originalImage, setOriginalImage] = useState<string | null>(null);
  const [editedImage, setEditedImage] = useState<string | null>(null);
  const [editPrompt, setEditPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [mimeType, setMimeType] = useState<string | null>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        setError('Please upload an image file (e.g., JPG, PNG).');
        setOriginalImage(null);
        setEditedImage(null);
        setMimeType(null);
        return;
      }
      setError(null);
      setEditedImage(null); // Clear edited image on new upload
      setMimeType(file.type);
      const reader = new FileReader();
      reader.onloadend = () => {
        setOriginalImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleEditImage = useCallback(async () => {
    if (!originalImage || !mimeType) {
      setError('Please upload an image first.');
      return;
    }
    if (!editPrompt.trim()) {
      setError('Please enter a prompt for editing the image.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setEditedImage(null);

    try {
      // Extract base64 data from the data URL
      const base64Data = originalImage.split(',')[1];
      const imageUrl = await geminiService.editImage(base64Data, mimeType, editPrompt);
      setEditedImage(imageUrl);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to edit image. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, [originalImage, mimeType, editPrompt, geminiService]);

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="flex flex-col p-4 md:p-8 max-w-4xl mx-auto bg-white shadow-lg rounded-xl">
      <h1 className="text-3xl font-bold text-gray-800 mb-6 text-center">
        AI Image Editor
      </h1>
      <p className="text-gray-600 mb-6 text-center">
        Upload an image and tell our AI (`gemini-2.5-flash-image`) what changes to make.
        "Add a retro filter", "Remove the background", or "Add a person in the corner".
      </p>

      <div className="mb-6">
        <label className="block text-lg font-medium text-gray-700 mb-2">
          Upload Image:
        </label>
        <input
          type="file"
          accept="image/*"
          onChange={handleFileChange}
          className="hidden"
          ref={fileInputRef}
        />
        <button
          onClick={triggerFileInput}
          className="w-full bg-gray-200 text-gray-800 font-semibold py-3 px-6 rounded-md hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-400 focus:ring-opacity-50 transition-colors duration-200"
          disabled={isLoading}
        >
          {originalImage ? 'Change Image' : 'Select Image'}
        </button>
        {originalImage && (
          <div className="mt-4 flex justify-center border border-gray-200 rounded-md p-2">
            <img src={originalImage} alt="Original" className="max-h-64 object-contain rounded-md" />
          </div>
        )}
      </div>

      <div className="mb-6">
        <label htmlFor="editPrompt" className="block text-lg font-medium text-gray-700 mb-2">
          What changes should I make?
        </label>
        <input
          id="editPrompt"
          type="text"
          value={editPrompt}
          onChange={(e) => setEditPrompt(e.target.value)}
          placeholder="e.g., Change the background to a starry night"
          className="w-full p-3 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 transition-colors"
          disabled={isLoading || !originalImage}
        />
      </div>

      <button
        onClick={handleEditImage}
        className="w-full bg-blue-600 text-white font-semibold py-3 px-6 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
        disabled={isLoading || !originalImage || !editPrompt.trim()}
      >
        {isLoading ? 'Editing Image...' : 'Apply Edits'}
      </button>

      {error && (
        <div className="mt-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded-md">
          <p className="font-semibold">Error:</p>
          <p>{error}</p>
        </div>
      )}

      {isLoading && <Spinner />}

      {editedImage && (
        <div className="mt-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-4 text-center">Edited Image:</h2>
          <div className="flex justify-center bg-gray-100 p-4 rounded-md border border-gray-200">
            <img
              src={editedImage}
              alt="Edited by AI"
              className="max-w-full h-auto rounded-lg shadow-md"
            />
          </div>
          <p className="text-center text-sm text-gray-500 mt-2">
            Right-click or long-press to save the image.
          </p>
        </div>
      )}
    </div>
  );
};

export default ImageEditor;
