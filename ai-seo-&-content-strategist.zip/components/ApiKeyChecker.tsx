
import React, { useState, useEffect } from 'react';

interface ApiKeyCheckerProps {
  onApiKeySelected: () => void;
  children: React.ReactNode;
}

// Fix: Define the AIStudio interface within declare global
// to match the expected type and resolve type declaration conflicts.
interface AIStudio {
  hasSelectedApiKey: () => Promise<boolean>;
  openSelectKey: () => Promise<void>;
}

declare global {
  interface Window {
    aistudio: AIStudio;
  }
}

const ApiKeyChecker: React.FC<ApiKeyCheckerProps> = ({ onApiKeySelected, children }) => {
  const [apiKeyStatus, setApiKeyStatus] = useState<'checking' | 'unselected' | 'selected'>('checking');
  const [isSelectingKey, setIsSelectingKey] = useState(false);

  const checkApiKey = async () => {
    if (!window.aistudio || !window.aistudio.hasSelectedApiKey) {
      console.warn("window.aistudio.hasSelectedApiKey not available. Assuming API key is handled externally.");
      setApiKeyStatus('selected');
      return;
    }
    try {
      const hasKey = await window.aistudio.hasSelectedApiKey();
      setApiKeyStatus(hasKey ? 'selected' : 'unselected');
      if (hasKey) {
        onApiKeySelected();
      }
    } catch (error) {
      console.error("Error checking API key status:", error);
      setApiKeyStatus('unselected');
    }
  };

  useEffect(() => {
    checkApiKey();
  }, []);

  const handleSelectKey = async () => {
    if (isSelectingKey) return; // Prevent multiple clicks
    setIsSelectingKey(true);
    try {
      if (window.aistudio && window.aistudio.openSelectKey) {
        await window.aistudio.openSelectKey();
        // Assume selection was successful and proceed.
        setApiKeyStatus('selected');
        onApiKeySelected();
      } else {
        alert("API key selection mechanism not available.");
        setApiKeyStatus('unselected');
      }
    } catch (error) {
      console.error("Error opening API key selection:", error);
      setApiKeyStatus('unselected'); // Stay unselected on error
    } finally {
      setIsSelectingKey(false);
    }
  };

  if (apiKeyStatus === 'checking') {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100 p-4">
        <div className="text-center text-gray-700">Checking API key status...</div>
      </div>
    );
  }

  if (apiKeyStatus === 'unselected') {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100 p-4">
        <div className="bg-white p-8 rounded-lg shadow-md text-center max-w-sm">
          <h2 className="text-xl font-semibold mb-4 text-red-600">API Key Required</h2>
          <p className="mb-6 text-gray-700">
            To use this feature (Image Generation), please select a Google Cloud Project with billing enabled.
            A paid API key is required.
          </p>
          <button
            onClick={handleSelectKey}
            disabled={isSelectingKey}
            className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 transition-colors duration-200 disabled:opacity-50"
          >
            {isSelectingKey ? 'Opening...' : 'Select API Key'}
          </button>
          <p className="mt-4 text-sm text-gray-500">
            <a
              href="https://ai.google.dev/gemini-api/docs/billing"
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-500 hover:underline"
            >
              Learn about billing for Gemini API
            </a>
          </p>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};

export default ApiKeyChecker;