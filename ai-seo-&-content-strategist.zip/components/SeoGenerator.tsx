import React, { useState, useCallback } from 'react';
import { GeminiService } from '../services/geminiService';
import { SeoOutput, GroundingChunk } from '../types';
import Spinner from './Spinner';
import CopyToClipboardButton from './CopyToClipboardButton'; // Import the new component

interface SeoGeneratorProps {
  geminiService: GeminiService;
}

const SeoGenerator: React.FC<SeoGeneratorProps> = ({ geminiService }) => {
  const [inputTitle, setInputTitle] = useState('');
  const [seoOutput, setSeoOutput] = useState<SeoOutput | null>(null);
  const [groundingUrls, setGroundingUrls] = useState<GroundingChunk[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = useCallback(async () => {
    if (!inputTitle.trim()) {
      setError('Please enter a title to generate SEO metadata.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setSeoOutput(null);
    setGroundingUrls([]);

    try {
      const { output, groundingUrls: fetchedUrls } = await geminiService.generateSeoMetadata(inputTitle);
      setSeoOutput(output);
      setGroundingUrls(fetchedUrls.filter(chunk => chunk.web?.uri)); // Filter out chunks without web URI
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to generate SEO metadata. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, [inputTitle, geminiService]);

  return (
    <div className="flex flex-col p-4 md:p-8 max-w-4xl mx-auto bg-white shadow-lg rounded-xl">
      <h1 className="text-3xl font-bold text-gray-800 mb-6 text-center">
        SEO & Content Metadata Generator
      </h1>
      <p className="text-gray-600 mb-6 text-center">
        Enter your content title, and our AI will generate optimized titles, a compelling SEO description, relevant tags, and hashtags to boost your reach.
      </p>

      <div className="mb-6">
        <label htmlFor="inputTitle" className="block text-lg font-medium text-gray-700 mb-2">
          Your Content Topic / Title:
        </label>
        <input
          id="inputTitle"
          type="text"
          value={inputTitle}
          onChange={(e) => setInputTitle(e.target.value)}
          placeholder="e.g., How to Master React Hooks in 2024"
          className="w-full p-3 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 transition-colors"
          disabled={isLoading}
        />
      </div>

      <button
        onClick={handleGenerate}
        className="w-full bg-blue-600 text-white font-semibold py-3 px-6 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
        disabled={isLoading}
      >
        {isLoading ? 'Generating...' : 'Generate SEO Metadata'}
      </button>

      {error && (
        <div className="mt-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded-md">
          <p className="font-semibold">Error:</p>
          <p>{error}</p>
        </div>
      )}

      {isLoading && <Spinner />}

      {seoOutput && (
        <div className="mt-8 space-y-8">
          <div>
            <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center">
              🎯 Optimized Titles:
              <CopyToClipboardButton 
                textToCopy={seoOutput.optimizedTitles.join('\n')} 
                label="Titles"
              />
            </h2>
            <ul className="list-disc list-inside space-y-2 text-gray-700 bg-gray-50 p-4 rounded-md border border-gray-200">
              {seoOutput.optimizedTitles.map((title, index) => (
                <li key={index}>
                  <span className="font-medium text-blue-700">Option {index + 1}:</span> {title}
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center">
              📝 SEO Description:
              <CopyToClipboardButton 
                textToCopy={seoOutput.seoDescription} 
                label="Description"
              />
            </h2>
            <p className="text-gray-700 leading-relaxed bg-gray-50 p-4 rounded-md border border-gray-200 whitespace-pre-wrap">
              {seoOutput.seoDescription}
            </p>
          </div>

          <div>
            <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center">
              🏷️ Tags:
              <CopyToClipboardButton 
                textToCopy={seoOutput.tags.join(', ')} 
                label="Tags"
              />
            </h2>
            <div className="flex flex-wrap gap-2 text-gray-700 bg-gray-50 p-4 rounded-md border border-gray-200">
              {seoOutput.tags.map((tag, index) => (
                <span key={index} className="bg-purple-100 text-purple-800 text-sm font-medium px-3 py-1 rounded-full">
                  {tag}
                </span>
              ))}
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center">
              #️⃣ Hashtags:
              <CopyToClipboardButton 
                textToCopy={seoOutput.hashtags.map(h => `#${h}`).join(' ')} 
                label="Hashtags"
              />
            </h2>
            <div className="flex flex-wrap gap-2 text-gray-700 bg-gray-50 p-4 rounded-md border border-gray-200">
              {seoOutput.hashtags.map((hashtag, index) => (
                <span key={index} className="bg-green-100 text-green-800 text-sm font-medium px-3 py-1 rounded-full">
                  #{hashtag}
                </span>
              ))}
            </div>
          </div>

          {groundingUrls.length > 0 && (
            <div>
              <h2 className="text-xl font-bold text-gray-800 mb-4">🔗 Grounding URLs (Google Search):</h2>
              <ul className="list-disc list-inside text-sm text-gray-600 space-y-1 bg-gray-50 p-4 rounded-md border border-gray-200">
                {groundingUrls.map((chunk, index) => chunk.web?.uri && (
                  <li key={index}>
                    <a
                      href={chunk.web.uri}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline"
                    >
                      {chunk.web.title || chunk.web.uri}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default SeoGenerator;