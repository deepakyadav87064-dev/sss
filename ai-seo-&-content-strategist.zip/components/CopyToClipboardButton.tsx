
import React, { useState } from 'react';

interface CopyToClipboardButtonProps {
  textToCopy: string;
  label?: string; // Optional label for accessibility/title
  className?: string; // Optional additional class names for styling
}

const CopyToClipboardButton: React.FC<CopyToClipboardButtonProps> = ({ textToCopy, label = 'Content', className = '' }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(textToCopy);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000); // Reset 'Copied!' state after 2 seconds
    } catch (err) {
      console.error('Failed to copy text: ', err);
      // Optionally provide user feedback for copy failure
    }
  };

  return (
    <button
      onClick={handleCopy}
      className={`ml-2 px-3 py-1 text-sm rounded-md transition-colors duration-200 ease-in-out
        ${copied ? 'bg-green-500 text-white' : 'bg-blue-100 text-blue-700 hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50'}
        ${className}`}
      aria-label={copied ? 'Copied to clipboard!' : `Copy ${label} to clipboard`}
      title={copied ? 'Copied!' : `Copy ${label}`}
      disabled={!textToCopy} // Disable if there's nothing to copy
    >
      {copied ? 'Copied!' : 'Copy'}
    </button>
  );
};

export default CopyToClipboardButton;