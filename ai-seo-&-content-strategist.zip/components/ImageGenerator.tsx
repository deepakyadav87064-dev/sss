import React, { useState, useCallback } from 'react';
import { GeminiService } from '../services/geminiService';
import { ImageSize, AspectRatio } from '../types';
import Spinner from './Spinner';
import ApiKeyChecker from './ApiKeyChecker'; // Import the API key checker

interface ImageGeneratorProps {
  geminiService: GeminiService;
}

const ImageGenerator: React.FC<ImageGeneratorProps> = ({ geminiService }) => {
  const [prompt, setPrompt] = useState('');
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [imageSize, setImageSize] = useState<ImageSize>('1K');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('1:1');
  const [apiKeySelected, setApiKeySelected] = useState(false); // State to track API key selection

  const handleGenerateImage = useCallback(async () => {
    if (!prompt.trim()) {
      setError('Please enter a prompt to generate an image.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setGeneratedImageUrl(null);

    try {
      const imageUrl = await geminiService.generateImage(prompt, imageSize, aspectRatio);
      setGeneratedImageUrl(imageUrl);
    } catch (err: any) {
      console.error(err);
      if (err.message && err.message.includes("Requested entity was not found.")) {
        setError('API Key error: Requested entity was not found. Please re-select your API key.');
        setApiKeySelected(false); // Reset key status to prompt re-selection
      } else {
        setError(err.message || 'Failed to generate image. Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  }, [prompt, imageSize, aspectRatio, geminiService]);

  const onApiKeySelected = useCallback(() => {
    setApiKeySelected(true);
    setError(null); // Clear any previous API key errors
  }, []);

  return (
    <ApiKeyChecker onApiKeySelected={onApiKeySelected}>
      <div className="flex flex-col p-4 md:p-8 max-w-4xl mx-auto bg-white shadow-lg rounded-xl">
        <h1 className="text-3xl font-bold text-gray-800 mb-6 text-center">
          AI Image Generator
        </h1>
        <p className="text-gray-600 mb-6 text-center">
          Describe the image you want to create, and our AI will bring it to life!
          Uses the powerful `gemini-3-pro-image-preview` model.
        </p>

        <div className="mb-6">
          <label htmlFor="imagePrompt" className="block text-lg font-medium text-gray-700 mb-2">
            Image Description:
          </label>
          <input
            id="imagePrompt"
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="e.g., A futuristic city at sunset with flying cars"
            className="w-full p-3 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 transition-colors"
            disabled={isLoading || !apiKeySelected}
          />
        </div>

        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="flex-1">
            <label htmlFor="imageSize" className="block text-lg font-medium text-gray-700 mb-2">
              Image Size:
            </label>
            <select
              id="imageSize"
              value={imageSize}
              onChange={(e) => setImageSize(e.target.value as ImageSize)}
              className="w-full p-3 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 transition-colors bg-white"
              disabled={isLoading || !apiKeySelected}
            >
              <option value="1K">1K (1024x1024)</option>
              <option value="2K">2K (2048x2048)</option>
              <option value="4K">4K (4096x4096)</option>
            </select>
            <p className="text-sm text-gray-500 mt-1">
              Higher resolutions (2K, 4K) may take longer to generate.
            </p>
          </div>

          <div className="flex-1">
            <label htmlFor="aspectRatio" className="block text-lg font-medium text-gray-700 mb-2">
              Aspect Ratio:
            </label>
            <select
              id="aspectRatio"
              value={aspectRatio}
              onChange={(e) => setAspectRatio(e.target.value as AspectRatio)}
              className="w-full p-3 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 transition-colors bg-white"
              disabled={isLoading || !apiKeySelected}
            >
              <option value="1:1">Square (1:1)</option>
              <option value="4:3">Standard (4:3)</option>
              <option value="3:4">Portrait (3:4)</option>
              <option value="16:9">Widescreen (16:9)</option>
              <option value="9:16">Tall (9:16)</option>
            </select>
          </div>
        </div>

        <button
          onClick={handleGenerateImage}
          className="w-full bg-blue-600 text-white font-semibold py-3 px-6 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
          disabled={isLoading || !apiKeySelected}
        >
          {isLoading ? 'Generating Image...' : 'Generate Image'}
        </button>

        {error && (
          <div className="mt-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded-md">
            <p className="font-semibold">Error:</p>
            <p>{error}</p>
          </div>
        )}

        {isLoading && <Spinner />}

        {generatedImageUrl && (
          <div className="mt-8">
            <h2 className="text-2xl font-bold text-gray-800 mb-4 text-center">Generated Image:</h2>
            <div className="flex justify-center bg-gray-100 p-4 rounded-md border border-gray-200">
              <img
                src={generatedImageUrl}
                alt="Generated by AI"
                className="max-w-full h-auto rounded-lg shadow-md"
              />
            </div>
            <p className="text-center text-sm text-gray-500 mt-2">
              Right-click or long-press to save the image.
            </p>
          </div>
        )}
      </div>
    </ApiKeyChecker>
  );
};

export default ImageGenerator;
