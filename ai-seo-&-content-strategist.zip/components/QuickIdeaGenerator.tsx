import React, { useState, useCallback } from 'react';
import { GeminiService } from '../services/geminiService';
import Spinner from './Spinner';

interface QuickIdeaGeneratorProps {
  geminiService: GeminiService;
}

const QuickIdeaGenerator: React.FC<QuickIdeaGeneratorProps> = ({ geminiService }) => {
  const [prompt, setPrompt] = useState('');
  const [ideaOutput, setIdeaOutput] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerateIdea = useCallback(async () => {
    if (!prompt.trim()) {
      setError('Please enter a prompt to generate an idea.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setIdeaOutput(null);

    try {
      const idea = await geminiService.generateQuickIdea(prompt);
      setIdeaOutput(idea);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to generate quick idea. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, [prompt, geminiService]);

  return (
    <div className="flex flex-col p-4 md:p-8 max-w-4xl mx-auto bg-white shadow-lg rounded-xl">
      <h1 className="text-3xl font-bold text-gray-800 mb-6 text-center">
        Quick Idea Generator
      </h1>
      <p className="text-gray-600 mb-6 text-center">
        Need a fast concept or a brief response? Get rapid ideas from `gemini-2.5-flash-lite`.
      </p>

      <div className="mb-6">
        <label htmlFor="ideaPrompt" className="block text-lg font-medium text-gray-700 mb-2">
          What idea are you looking for?
        </label>
        <input
          id="ideaPrompt"
          type="text"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="e.g., Suggest 3 unique video content ideas for a tech channel"
          className="w-full p-3 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 transition-colors"
          disabled={isLoading}
        />
      </div>

      <button
        onClick={handleGenerateIdea}
        className="w-full bg-blue-600 text-white font-semibold py-3 px-6 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
        disabled={isLoading || !prompt.trim()}
      >
        {isLoading ? 'Generating Idea...' : 'Get Quick Idea'}
      </button>

      {error && (
        <div className="mt-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded-md">
          <p className="font-semibold">Error:</p>
          <p>{error}</p>
        </div>
      )}

      {isLoading && <Spinner />}

      {ideaOutput && (
        <div className="mt-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Your Idea:</h2>
          <div className="bg-gray-50 p-4 rounded-md border border-gray-200 text-gray-700 leading-relaxed whitespace-pre-wrap">
            {ideaOutput}
          </div>
        </div>
      )}
    </div>
  );
};

export default QuickIdeaGenerator;
