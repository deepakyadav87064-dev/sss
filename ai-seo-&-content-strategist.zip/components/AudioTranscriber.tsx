import React, { useState, useCallback, useEffect, useRef } from 'react';
import { GeminiService } from '../services/geminiService';
import Spinner from './Spinner';

interface AudioTranscriberProps {
  geminiService: GeminiService;
}

const AudioTranscriber: React.FC<AudioTranscriberProps> = ({ geminiService }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [inputTranscription, setInputTranscription] = useState('');
  const [outputTranscription, setOutputTranscription] = useState('');
  const [fullConversation, setFullConversation] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Audio output context for playing model's responses
  const outputAudioContextRef = useRef<AudioContext | null>(null);

  const handleTranscriptionUpdate = useCallback((input: string, output: string, turnComplete: boolean) => {
    setInputTranscription(input);
    setOutputTranscription(output);
    if (turnComplete) {
      setFullConversation(prev => [...prev, `You: ${input}`, `AI: ${output}`]);
      setInputTranscription('');
      setOutputTranscription('');
    }
  }, []);

  const handleAudioOutput = useCallback(async (audioBuffer: AudioBuffer) => {
    if (!outputAudioContextRef.current) {
      // Initialize AudioContext if not already initialized
      // Fix: Use `window.AudioContext` for modern browsers.
      outputAudioContextRef.current = new AudioContext({ sampleRate: 24000 });
    }
    const source = outputAudioContextRef.current.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(outputAudioContextRef.current.destination);
    source.start();
  }, []);

  const handleStartRecording = useCallback(async () => {
    setIsRecording(true);
    setIsLoading(true);
    setError(null);
    setInputTranscription('');
    setOutputTranscription('');
    setFullConversation([]);

    try {
      await geminiService.startAudioTranscription(
        handleTranscriptionUpdate,
        handleAudioOutput,
        (e) => {
          setError(`Audio error: ${e.message || 'Unknown error'}`);
          setIsRecording(false);
          setIsLoading(false);
        },
        (e) => {
          console.debug('Live session closed:', e);
          setIsRecording(false);
          setIsLoading(false);
        }
      );
      setIsLoading(false);
    } catch (err: any) {
      console.error('Failed to start audio transcription:', err);
      setError(err.message || 'Failed to start microphone. Please ensure permissions are granted.');
      setIsRecording(false);
      setIsLoading(false);
    }
  }, [geminiService, handleTranscriptionUpdate, handleAudioOutput]);

  const handleStopRecording = useCallback(() => {
    geminiService.stopAudioTranscription();
    setIsRecording(false);
    setIsLoading(false);
    if (outputAudioContextRef.current) {
      outputAudioContextRef.current.close().catch(e => console.error("Error closing output audio context:", e));
      outputAudioContextRef.current = null;
    }
  }, [geminiService]);

  useEffect(() => {
    // Cleanup on component unmount
    return () => {
      if (isRecording) {
        handleStopRecording();
      }
    };
  }, [isRecording, handleStopRecording]);


  return (
    <div className="flex flex-col p-4 md:p-8 max-w-4xl mx-auto bg-white shadow-lg rounded-xl">
      <h1 className="text-3xl font-bold text-gray-800 mb-6 text-center">
        AI Audio Transcriber & Live Chat
      </h1>
      <p className="text-gray-600 mb-6 text-center">
        Speak into your microphone and our AI (`gemini-2.5-flash-native-audio-preview-12-2025`) will transcribe your input
        and respond in real-time. (Requires microphone permission)
      </p>

      <div className="flex justify-center mb-6 space-x-4">
        <button
          onClick={handleStartRecording}
          disabled={isRecording || isLoading}
          className={`px-8 py-3 rounded-full text-white font-semibold transition-colors duration-200
            ${isRecording || isLoading ? 'bg-gray-400 cursor-not-allowed' : 'bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-opacity-50'}`}
        >
          {isLoading ? 'Connecting...' : 'Start Recording'}
        </button>
        <button
          onClick={handleStopRecording}
          disabled={!isRecording && !isLoading}
          className={`px-8 py-3 rounded-full text-white font-semibold transition-colors duration-200
            ${(!isRecording && !isLoading) ? 'bg-gray-400 cursor-not-allowed' : 'bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-opacity-50'}`}
        >
          Stop Recording
        </button>
      </div>

      {error && (
        <div className="mt-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded-md">
          <p className="font-semibold">Error:</p>
          <p>{error}</p>
          <p className="text-sm mt-2">
            Please ensure your microphone is connected and browser permissions are granted.
          </p>
        </div>
      )}

      {isLoading && <Spinner />}

      <div className="mt-8 space-y-4">
        <div className="bg-blue-50 p-4 rounded-md border border-blue-200">
          <h2 className="text-lg font-bold text-blue-800 mb-2">Your Input:</h2>
          <p className="text-blue-700 min-h-[1.5em]">{inputTranscription}</p>
        </div>
        <div className="bg-purple-50 p-4 rounded-md border border-purple-200">
          <h2 className="text-lg font-bold text-purple-800 mb-2">AI Response:</h2>
          <p className="text-purple-700 min-h-[1.5em]">{outputTranscription}</p>
        </div>

        {fullConversation.length > 0 && (
          <div className="bg-gray-100 p-4 rounded-md border border-gray-200 max-h-60 overflow-y-auto">
            <h2 className="text-lg font-bold text-gray-800 mb-2">Conversation History:</h2>
            <div className="space-y-2 text-sm text-gray-700">
              {fullConversation.map((line, index) => (
                <p key={index} className={line.startsWith('You:') ? 'font-medium text-gray-900' : 'text-gray-700'}>
                  {line}
                </p>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AudioTranscriber;