import React, { useState, useCallback, useEffect, useRef } from 'react';
import { GeminiService } from '../services/geminiService';
import Spinner from './Spinner';

interface ChatbotProps {
  geminiService: GeminiService;
}

interface ChatMessage {
  sender: 'user' | 'ai';
  text: string;
}

const Chatbot: React.FC<ChatbotProps> = ({ geminiService }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = useCallback(async () => {
    if (!inputMessage.trim()) return;

    const newMessage: ChatMessage = { sender: 'user', text: inputMessage };
    setMessages((prev) => [...prev, newMessage]);
    setInputMessage('');
    setIsLoading(true);
    setError(null);

    const aiResponseId = `ai-temp-${Date.now()}`; // Unique ID for temporary AI message

    // Add a placeholder AI message for streaming
    setMessages((prev) => [...prev, { sender: 'ai', text: '', id: aiResponseId } as ChatMessage]);


    try {
      let fullResponse = '';
      await geminiService.sendMessageToChat(inputMessage, (chunk) => {
        fullResponse += chunk;
        setMessages((prev) =>
          prev.map((msg) =>
            (msg as any).id === aiResponseId ? { ...msg, text: fullResponse } : msg
          )
        );
      });
    } catch (err: any) {
      console.error('Chat error:', err);
      setError(err.message || 'Failed to get a response. Please try again.');
      // Remove or mark the placeholder if error occurs
      setMessages((prev) =>
        prev.filter((msg) => (msg as any).id !== aiResponseId)
      );
    } finally {
      setIsLoading(false);
      // Ensure the placeholder is replaced by the final message or removed on error
      setMessages((prev) =>
        prev.map((msg) =>
          (msg as any).id === aiResponseId ? { ...msg, id: undefined } : msg
        )
      );
    }
  }, [inputMessage, geminiService]);

  const handleKeyPress = useCallback((e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !isLoading) {
      handleSendMessage();
    }
  }, [handleSendMessage, isLoading]);

  useEffect(() => {
    // Initialize chat session when component mounts
    geminiService.startNewChat().catch(err => {
      console.error("Failed to start new chat session:", err);
      setError("Failed to start chat. Please refresh.");
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // Run only once on mount

  return (
    <div className="flex flex-col h-full p-4 md:p-8 max-w-4xl mx-auto bg-white shadow-lg rounded-xl">
      <h1 className="text-3xl font-bold text-gray-800 mb-6 text-center">
        AI Chatbot
      </h1>
      <p className="text-gray-600 mb-6 text-center">
        Ask any questions related to SEO, content strategy, or social media,
        and get intelligent responses from `gemini-3-pro-preview`.
      </p>

      <div className="flex-1 overflow-y-auto p-4 border border-gray-200 rounded-lg mb-6 bg-gray-50 flex flex-col space-y-4">
        {messages.length === 0 && !isLoading && (
          <p className="text-center text-gray-500 italic">Start a conversation!</p>
        )}
        {messages.map((msg, index) => (
          <div
            key={index}
            className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[70%] p-3 rounded-lg shadow-md ${
                msg.sender === 'user'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-200 text-gray-800'
              }`}
            >
              <p className="whitespace-pre-wrap">{msg.text}</p>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="max-w-[70%] p-3 rounded-lg shadow-md bg-gray-200 text-gray-800">
              <Spinner />
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded-md">
          <p className="font-semibold">Error:</p>
          <p>{error}</p>
        </div>
      )}

      <div className="flex gap-4">
        <input
          type="text"
          value={inputMessage}
          onChange={(e) => setInputMessage(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Type your message..."
          className="flex-1 p-3 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 transition-colors"
          disabled={isLoading}
        />
        <button
          onClick={handleSendMessage}
          className="bg-blue-600 text-white font-semibold py-3 px-6 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
          disabled={isLoading || !inputMessage.trim()}
        >
          Send
        </button>
      </div>
    </div>
  );
};

export default Chatbot;
