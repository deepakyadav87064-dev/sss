import React, { useState, useCallback, useRef } from 'react';
import { GeminiService } from '../services/geminiService';
import Spinner from './Spinner';

interface ImageAnalyzerProps {
  geminiService: GeminiService;
}

const ImageAnalyzer: React.FC<ImageAnalyzerProps> = ({ geminiService }) => {
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);
  const [userPrompt, setUserPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [mimeType, setMimeType] = useState<string | null>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        setError('Please upload an image file (e.g., JPG, PNG).');
        setUploadedImage(null);
        setAnalysisResult(null);
        setMimeType(null);
        return;
      }
      setError(null);
      setAnalysisResult(null); // Clear previous analysis on new upload
      setMimeType(file.type);
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyzeImage = useCallback(async () => {
    if (!uploadedImage || !mimeType) {
      setError('Please upload an image first.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setAnalysisResult(null);

    try {
      const base64Data = uploadedImage.split(',')[1];
      const result = await geminiService.analyzeImage(base64Data, mimeType, userPrompt);
      setAnalysisResult(result);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to analyze image. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, [uploadedImage, mimeType, userPrompt, geminiService]);

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="flex flex-col p-4 md:p-8 max-w-4xl mx-auto bg-white shadow-lg rounded-xl">
      <h1 className="text-3xl font-bold text-gray-800 mb-6 text-center">
        AI Image Analyzer
      </h1>
      <p className="text-gray-600 mb-6 text-center">
        Upload a photo, and our AI (`gemini-3-pro-preview`) will describe it,
        suggest SEO keywords, and generate content ideas based on the image.
      </p>

      <div className="mb-6">
        <label className="block text-lg font-medium text-gray-700 mb-2">
          Upload Image:
        </label>
        <input
          type="file"
          accept="image/*"
          onChange={handleFileChange}
          className="hidden"
          ref={fileInputRef}
        />
        <button
          onClick={triggerFileInput}
          className="w-full bg-gray-200 text-gray-800 font-semibold py-3 px-6 rounded-md hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-400 focus:ring-opacity-50 transition-colors duration-200"
          disabled={isLoading}
        >
          {uploadedImage ? 'Change Image' : 'Select Image'}
        </button>
        {uploadedImage && (
          <div className="mt-4 flex justify-center border border-gray-200 rounded-md p-2">
            <img src={uploadedImage} alt="Uploaded" className="max-h-64 object-contain rounded-md" />
          </div>
        )}
      </div>

      <div className="mb-6">
        <label htmlFor="analysisPrompt" className="block text-lg font-medium text-gray-700 mb-2">
          Specific question about the image (Optional):
        </label>
        <input
          id="analysisPrompt"
          type="text"
          value={userPrompt}
          onChange={(e) => setUserPrompt(e.target.value)}
          placeholder="e.g., What emotions does this image evoke? Or suggest a catchy caption."
          className="w-full p-3 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 transition-colors"
          disabled={isLoading || !uploadedImage}
        />
      </div>

      <button
        onClick={handleAnalyzeImage}
        className="w-full bg-blue-600 text-white font-semibold py-3 px-6 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
        disabled={isLoading || !uploadedImage}
      >
        {isLoading ? 'Analyzing Image...' : 'Analyze Image'}
      </button>

      {error && (
        <div className="mt-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded-md">
          <p className="font-semibold">Error:</p>
          <p>{error}</p>
        </div>
      )}

      {isLoading && <Spinner />}

      {analysisResult && (
        <div className="mt-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Analysis Result:</h2>
          <div className="bg-gray-50 p-4 rounded-md border border-gray-200 text-gray-700 leading-relaxed whitespace-pre-wrap">
            {analysisResult}
          </div>
        </div>
      )}
    </div>
  );
};

export default ImageAnalyzer;
