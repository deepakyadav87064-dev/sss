export interface SeoOutput {
  optimizedTitles: string[];
  seoDescription: string;
  tags: string[];
  hashtags: string[];
}

export interface GroundingChunk {
  web?: {
    uri?: string;
    title?: string;
  };
}

export interface ImageAnalysisResult {
  description: string;
}

export enum AppFeature {
  SeoGenerator = 'SEO Generator',
  ImageGenerator = 'Image Generator',
  ImageEditor = 'Image Editor',
  ImageAnalyzer = 'Image Analyzer',
  AudioTranscriber = 'Audio Transcriber',
  Chatbot = 'Chatbot',
  QuickIdea = 'Quick Idea' // For gemini-2.5-flash-lite
}

export type ImageSize = '1K' | '2K' | '4K';

export type AspectRatio = '1:1' | '3:4' | '4:3' | '9:16' | '16:9';
