import React, { useState, useEffect, useMemo } from 'react';
import { GeminiService } from './services/geminiService';
import SeoGenerator from './components/SeoGenerator';
import ImageGenerator from './components/ImageGenerator';
import ImageEditor from './components/ImageEditor';
import ImageAnalyzer from './components/ImageAnalyzer';
import AudioTranscriber from './components/AudioTranscriber';
import Chatbot from './components/Chatbot';
import QuickIdeaGenerator from './components/QuickIdeaGenerator';
import { AppFeature } from './types';

function App() {
  const [activeFeature, setActiveFeature] = useState<AppFeature>(AppFeature.SeoGenerator);
  const [geminiService, setGeminiService] = useState<GeminiService | null>(null);
  const [apiKeyError, setApiKeyError] = useState<string | null>(null);

  useEffect(() => {
    // Check if API_KEY is available in process.env
    if (process.env.API_KEY) {
      setGeminiService(new GeminiService({ apiKey: process.env.API_KEY }));
    } else {
      setApiKeyError('API_KEY is not configured. Please ensure process.env.API_KEY is set.');
      console.error('API_KEY is not defined. GeminiService cannot be initialized.');
    }
  }, []);

  const featureComponents = useMemo(() => {
    if (!geminiService) {
      return null;
    }
    return {
      [AppFeature.SeoGenerator]: <SeoGenerator geminiService={geminiService} />,
      [AppFeature.ImageGenerator]: <ImageGenerator geminiService={geminiService} />,
      [AppFeature.ImageEditor]: <ImageEditor geminiService={geminiService} />,
      [AppFeature.ImageAnalyzer]: <ImageAnalyzer geminiService={geminiService} />,
      [AppFeature.AudioTranscriber]: <AudioTranscriber geminiService={geminiService} />,
      [AppFeature.Chatbot]: <Chatbot geminiService={geminiService} />,
      [AppFeature.QuickIdea]: <QuickIdeaGenerator geminiService={geminiService} />,
    };
  }, [geminiService]);


  if (apiKeyError) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100 p-4">
        <div className="bg-white p-8 rounded-lg shadow-md text-center max-w-sm">
          <h2 className="text-xl font-semibold mb-4 text-red-600">Configuration Error</h2>
          <p className="mb-6 text-gray-700">{apiKeyError}</p>
          <p className="text-sm text-gray-500">
            Please ensure your environment is correctly set up with `process.env.API_KEY`.
          </p>
        </div>
      </div>
    );
  }

  if (!geminiService && !apiKeyError) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100 p-4">
        <div className="text-center text-gray-700">Initializing AI services...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      {/* Header with navigation */}
      <header className="bg-white shadow-md p-4 sticky top-0 z-10">
        <nav className="flex flex-wrap justify-center gap-2 md:gap-4 max-w-6xl mx-auto">
          {Object.values(AppFeature).map((feature) => (
            <button
              key={feature}
              onClick={() => setActiveFeature(feature)}
              className={`px-3 py-2 md:px-4 md:py-2 text-sm md:text-base font-medium rounded-md transition-colors duration-200
                ${activeFeature === feature
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-gray-700 hover:bg-gray-200 bg-gray-100'
                }`}
            >
              {feature}
            </button>
          ))}
        </nav>
      </header>

      {/* Main content area */}
      <main className="flex-1 p-4 overflow-y-auto">
        {featureComponents ? featureComponents[activeFeature] : null}
      </main>

      {/* Footer can be added here if needed */}
    </div>
  );
}

export default App;
