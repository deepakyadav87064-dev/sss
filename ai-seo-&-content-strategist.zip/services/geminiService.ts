import {
  GoogleGenAI,
  GenerateContentResponse,
  Chat,
  Type,
  FunctionDeclaration,
  Modality,
  LiveServerMessage,
  Blob,
} from '@google/genai';
import { SeoOutput, ImageSize, AspectRatio, GroundingChunk } from '../types';

interface GeminiServiceConfig {
  apiKey: string;
}

// Function to encode Uint8Array to base64 string
function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

// Function to decode base64 string to Uint8Array
function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

// Function to decode PCM audio data to AudioBuffer
async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

// Function to create a PCM Blob from Float32Array
function createPcmBlob(data: Float32Array): Blob {
  const l = data.length;
  const int16 = new Int16Array(l);
  for (let i = 0; i < l; i++) {
    int16[i] = data[i] * 32768;
  }
  return {
    data: encode(new Uint8Array(int16.buffer)),
    mimeType: 'audio/pcm;rate=16000', // Supported audio MIME type
  };
}

export class GeminiService {
  private ai: GoogleGenAI;
  private currentChat: Chat | null = null;
  private liveSessionPromise: Promise<any> | null = null;
  private inputAudioContext: AudioContext | null = null;
  private outputAudioContext: AudioContext | null = null;
  private scriptProcessor: ScriptProcessorNode | null = null;
  private outputAudioSources: Set<AudioBufferSourceNode> = new Set<AudioBufferSourceNode>();
  private nextStartTime: number = 0;

  constructor(config: GeminiServiceConfig) {
    this.ai = new GoogleGenAI({ apiKey: config.apiKey });
  }

  // --- Core SEO Generation ---
  async generateSeoMetadata(inputTitle: string): Promise<{ output: SeoOutput | null, groundingUrls: GroundingChunk[] }> {
    // Always create a new GoogleGenAI instance right before an API call to ensure the latest API key is used.
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY }); 
    const prompt = `Act as a Senior SEO Specialist and Content Strategist for YouTube and Social Media.
Your goal is to generate high-ranking SEO metadata to maximize views and engagement for the following content title: '${inputTitle}'.

Please generate the following output in a structured JSON format. Ensure all strings within arrays are comma-separated for readability, but the overall structure should remain JSON.

1.  🎯 OPTIMIZED TITLES (Give 3 variations):
    -   High CTR (Click-Through Rate)
    -   Contains primary keywords
    -   Emotional or curious hook
2.  📝 SEO DESCRIPTION (150-200 words):
    -   First 2 lines: compelling hook including the main keyword.
    -   Middle: Brief summary of the content using semantic keywords (LSI).
    -   End: Call to Action (Subscribe/Follow/Link).
3.  🏷️ TAGS (Provide as an array of strings):
    -   Generate approximately 800 relevant tags (keywords), including a mix of broad, specific, and long-tail keywords. Aim for high search volume keywords relevant to the topic.
4.  #️⃣ HASHTAGS (Provide as an array of strings):
    -   Generate approximately 800 relevant hashtags. For hashtags, generate the text content without the leading '#' symbol, as the application will add it for display and copying. Include a mix of broad, niche, and highly specific hashtags.

Keep the tone engaging and natural.`;

    try {
      const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: prompt,
        config: {
          thinkingConfig: { thinkingBudget: 1024 }, // Reserve 1024 tokens for thinking
          maxOutputTokens: 8192, // Increased max output tokens to accommodate many tags/hashtags
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              optimizedTitles: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              seoDescription: { type: Type.STRING },
              tags: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              hashtags: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
            },
            required: ['optimizedTitles', 'seoDescription', 'tags', 'hashtags'],
          },
          tools: [{ googleSearch: {} }],
        },
      });

      const jsonStr = response.text?.trim();
      let output: SeoOutput | null = null;
      let groundingUrls: GroundingChunk[] = [];

      if (jsonStr) {
        try {
          output = JSON.parse(jsonStr) as SeoOutput;
        } catch (parseError) {
          console.error("Failed to parse JSON response:", parseError);
          // Fallback if parsing fails, try to extract parts from text
          output = {
            optimizedTitles: ["Could not parse titles"],
            seoDescription: "Could not parse description",
            tags: ["Could not parse tags"],
            hashtags: ["Could not parse hashtags"]
          };
        }
      }

      // Extract grounding URLs
      groundingUrls = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];

      return { output, groundingUrls };
    } catch (error) {
      console.error('Error generating SEO metadata:', error);
      throw error;
    }
  }

  // --- Image Generation ---
  async generateImage(prompt: string, imageSize: ImageSize, aspectRatio: AspectRatio): Promise<string> {
    // Always create a new GoogleGenAI instance right before an API call to ensure the latest API key is used.
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY }); 
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-image-preview',
        contents: {
          parts: [{ text: prompt }],
        },
        config: {
          imageConfig: {
            aspectRatio: aspectRatio,
            imageSize: imageSize,
          },
          tools: [{ googleSearch: {} }], // Available for gemini-3-pro-image-preview
        },
      });

      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          return `data:image/png;base64,${part.inlineData.data}`;
        }
      }
      throw new Error('No image data found in the response.');
    } catch (error) {
      console.error('Error generating image:', error);
      throw error;
    }
  }

  // --- Image Editing ---
  async editImage(base64ImageData: string, mimeType: string, prompt: string): Promise<string> {
    // Always create a new GoogleGenAI instance right before an API call to ensure the latest API key is used.
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY }); 
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [
            {
              inlineData: {
                data: base64ImageData,
                mimeType: mimeType,
              },
            },
            {
              text: prompt,
            },
          ],
        },
      });

      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          return `data:image/png;base64,${part.inlineData.data}`;
        }
      }
      throw new Error('No edited image data found in the response.');
    } catch (error) {
      console.error('Error editing image:', error);
      throw error;
    }
  }

  // --- Image Analysis ---
  async analyzeImage(base64ImageData: string, mimeType: string, userPrompt?: string): Promise<string> {
    // Always create a new GoogleGenAI instance right before an API call to ensure the latest API key is used.
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY }); 
    const prompt = userPrompt || 'Describe this image in detail and suggest potential SEO keywords or content ideas based on its visual elements.';
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: {
          parts: [
            {
              inlineData: {
                data: base64ImageData,
                mimeType: mimeType,
              },
            },
            { text: prompt },
          ],
        },
      });
      return response.text || 'No description generated.';
    } catch (error) {
      console.error('Error analyzing image:', error);
      throw error;
    }
  }

  // --- Chatbot ---
  async startNewChat(): Promise<void> {
    // Always create a new GoogleGenAI instance right before an API call to ensure the latest API key is used.
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY }); 
    this.currentChat = ai.chats.create({
      model: 'gemini-3-pro-preview',
      config: {
        systemInstruction: 'You are an AI SEO and Content Strategist assistant. Provide helpful, concise, and actionable advice related to SEO, content strategy, and social media. You can answer questions about generated metadata, suggest improvements, or provide general SEO insights.',
      },
    });
  }

  async sendMessageToChat(message: string, onNewChunk: (chunk: string) => void): Promise<void> {
    if (!this.currentChat) {
      await this.startNewChat();
    }
    try {
      const streamResponse = await this.currentChat!.sendMessageStream({ message: message });
      for await (const chunk of streamResponse) {
        onNewChunk(chunk.text || '');
      }
    } catch (error) {
      console.error('Error sending message to chat:', error);
      throw error;
    }
  }

  // --- Quick Idea Generator (gemini-2.5-flash-lite) ---
  async generateQuickIdea(prompt: string): Promise<string> {
    // Always create a new GoogleGenAI instance right before an API call to ensure the latest API key is used.
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY }); 
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-lite',
        contents: prompt,
        config: {
          // A smaller thinking budget for faster responses if needed, or default
          thinkingConfig: { thinkingBudget: 0 },
          maxOutputTokens: 100, // Limit output for 'quick' idea
        },
      });
      return response.text || 'No quick idea generated.';
    } catch (error) {
      console.error('Error generating quick idea:', error);
      throw error;
    }
  }

  // --- Audio Transcriber (Live API) ---
  async startAudioTranscription(
    onTranscription: (input: string, output: string, complete: boolean) => void,
    onAudioOutput: (audioBuffer: AudioBuffer) => void,
    onError: (error: ErrorEvent) => void,
    onClose: (event: CloseEvent) => void
  ): Promise<void> {
    // Always create a new GoogleGenAI instance right before an API call to ensure the latest API key is used.
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY }); 

    if (this.inputAudioContext && this.inputAudioContext.state === 'running') {
      console.warn("Audio context already running. Stopping previous session.");
      this.stopAudioTranscription();
    }

    // Fix: Use `window.AudioContext` for modern browsers.
    this.inputAudioContext = new AudioContext({ sampleRate: 16000 });
    // Fix: Use `window.AudioContext` for modern browsers.
    this.outputAudioContext = new AudioContext({ sampleRate: 24000 });
    this.nextStartTime = 0;
    this.outputAudioSources.clear();

    let currentInputTranscription = '';
    let currentOutputTranscription = '';

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const source = this.inputAudioContext.createMediaStreamSource(stream);
      this.scriptProcessor = this.inputAudioContext.createScriptProcessor(4096, 1, 1);

      this.scriptProcessor.onaudioprocess = (audioProcessingEvent) => {
        const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
        const pcmBlob = createPcmBlob(inputData);
        if (this.liveSessionPromise) {
          this.liveSessionPromise.then((session) => {
            session.sendRealtimeInput({ media: pcmBlob });
          }).catch(e => console.error("Error sending real-time input:", e));
        }
      };

      source.connect(this.scriptProcessor);
      this.scriptProcessor.connect(this.inputAudioContext.destination);

      this.liveSessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            console.debug('Live session opened.');
            currentInputTranscription = '';
            currentOutputTranscription = '';
          },
          onmessage: async (message: LiveServerMessage) => {
            if (message.serverContent?.inputTranscription) {
              currentInputTranscription += message.serverContent.inputTranscription.text;
            }
            if (message.serverContent?.outputTranscription) {
              currentOutputTranscription += message.serverContent.outputTranscription.text;
            }
            if (message.serverContent?.turnComplete) {
              onTranscription(currentInputTranscription, currentOutputTranscription, true);
              currentInputTranscription = '';
              currentOutputTranscription = '';
            } else {
              onTranscription(currentInputTranscription, currentOutputTranscription, false);
            }

            const base64EncodedAudioString = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64EncodedAudioString && this.outputAudioContext) {
              this.nextStartTime = Math.max(this.nextStartTime, this.outputAudioContext.currentTime);
              try {
                const audioBuffer = await decodeAudioData(
                  decode(base64EncodedAudioString),
                  this.outputAudioContext,
                  24000,
                  1,
                );
                onAudioOutput(audioBuffer); // Pass the buffer to the component for playback
                const source = this.outputAudioContext.createBufferSource();
                source.buffer = audioBuffer;
                source.connect(this.outputAudioContext.destination); // Direct to speakers
                source.addEventListener('ended', () => {
                  this.outputAudioSources.delete(source);
                });
                source.start(this.nextStartTime);
                this.nextStartTime = this.nextStartTime + audioBuffer.duration;
                this.outputAudioSources.add(source);
              } catch (audioDecodeError) {
                console.error("Error decoding audio data:", audioDecodeError);
              }
            }

            if (message.serverContent?.interrupted) {
              for (const source of this.outputAudioSources.values()) {
                source.stop();
                this.outputAudioSources.delete(source);
              }
              this.nextStartTime = 0;
            }
          },
          onerror: (e: ErrorEvent) => {
            console.error('Live session error:', e);
            onError(e);
            this.stopAudioTranscription();
          },
          onclose: (e: CloseEvent) => {
            console.debug('Live session closed:', e);
            onClose(e);
            this.stopAudioTranscription();
          },
        },
        config: {
          responseModalities: [Modality.AUDIO],
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
          },
          systemInstruction: 'You are a helpful SEO assistant. Transcribe and respond verbally. If user asks for SEO related query, give concise answers.',
        },
      });
    } catch (error) {
      console.error('Error starting audio transcription:', error);
      onError(new ErrorEvent('Error', { error: error }));
      this.stopAudioTranscription(); // Ensure resources are released on initial error
    }
  }

  stopAudioTranscription(): void {
    if (this.scriptProcessor && this.inputAudioContext) {
      this.scriptProcessor.disconnect();
      this.inputAudioContext.close().catch(e => console.error("Error closing input audio context:", e));
      this.scriptProcessor = null;
      this.inputAudioContext = null;
    }
    if (this.outputAudioContext) {
      for (const source of this.outputAudioSources.values()) {
        source.stop();
      }
      this.outputAudioSources.clear();
      this.outputAudioContext.close().catch(e => console.error("Error closing output audio context:", e));
      this.outputAudioContext = null;
    }
    if (this.liveSessionPromise) {
      this.liveSessionPromise.then(session => session.close()).catch(e => console.error("Error closing live session:", e));
      this.liveSessionPromise = null;
    }
    this.nextStartTime = 0;
    console.debug('Audio transcription stopped.');
  }

}